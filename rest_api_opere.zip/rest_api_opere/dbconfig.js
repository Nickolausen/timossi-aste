const config = {
    user: "sa",
    password:"burbero2023",
    server: "localhost",
    database: "DB_Timossi",
    options: {
        trustedconnection: true,
        trustServerCertificate: true,
        instancename: "SQLEXPRESS"
    },
}

module.exports = config;